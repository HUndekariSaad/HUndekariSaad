export const environment = {
  production: true,
  // baseUrl: 'http://172.16.16.12:8090/',
  // baseUrls: 'http://172.16.16.12:8090/',

  // baseUrl2: 'http://172.16.16.12:8091/',
  // baseUrls2: 'http://172.16.16.12:8091/',


  baseUrl: 'https://techsupport.visel.in:8090/',
  baseUrls: 'https://techsupport.visel.in:8090/',

  baseUrl2: 'http://techsupport.visel.in:8090/',
  baseUrls2: 'http://techsupport.visel.in:8090/',
};
