import { Injectable } from '@angular/core';
import { UrlsService } from './urls.service';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';
import { Login } from '../modules/login';
import { Pagination } from '../modules/_modules/pagination';
import { catchError, map, Subject, tap } from 'rxjs';



var token = localStorage.getItem('token');
var headers = new HttpHeaders()
  .set('content-type', 'application/json')
  .set('Access-Control-Allow-Origin', '*')
  .set('Authorization', 'Bearer ' + token);
@Injectable({
  providedIn: 'root'
})

export class ApiService {
  forkJoin(arg0: any[]) {
    throw new Error('Method not implemented.');
  }

  baseUrl = environment.baseUrl;
  baseUrls = environment.baseUrls;

  baseUrl2 = environment.baseUrl2;
  baseUrls2 = environment.baseUrls2;

  pagination!: Pagination

  constructor(private http: HttpClient, public urls: UrlsService) { }
  private _refreshNeeded$ = new Subject<void>();
  // LOGIN_METHOD
  PostLoginDetails(data: Login): Observable<any> {
    return this.http.post(this.baseUrls2 + this.urls.PostLoginDetails, data).pipe(map(
      response => {
        return response;
      }))
      .pipe(catchError(err => {
        // i cannot get anything here
        console.log(err);
        return err;
      }));

  }

  get refreshNeeded(){
    return this._refreshNeeded$
  }
  //GET_Profile_METHOD
  GetProfile(): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 + this.urls.loginProfile, { 'headers': headers });
  }

  //GET_Profile_METHOD
  ComplaintSummary(): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 + this.urls.complaintSummary, { 'headers': headers });
  }


  //GET_REPORTS_METHOD

  GetComplaintList(): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 + this.urls.get_complaint_list, { 'headers': headers });
  }

  //GET_REPORTS_METHOD
  GetOpenTicketsPendingList(): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 + this.urls.get_complaint_pending_list, { 'headers': headers });

  }
  GetOpenTicketsNewList(): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 + this.urls.get_complaint_new_list, { 'headers': headers });
  };
  GetUserCoordinatorList(): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 + this.urls.get_user_coordinator_list, { 'headers': headers });
  }
  GetBankMitraKocodeList(): Observable<any> {
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 + this.urls.get_bank_mitra_Kocode_list, { 'headers': headers });
  }




  ImportExcel(data: any): Observable<Blob> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('Content-Type', 'multipart/form-data')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.post(this.baseUrl2 + this.urls.post_complaint_excel, data, { responseType: 'blob','headers': headers });
  }





  ImportExcelFile(formData: any): Observable<any> {
    // var token = localStorage.getItem('token');
    // var headers = new HttpHeaders()
    //   .set('content-type', 'application/json')
    //   .set('Access-Control-Allow-Origin', '*')
    //   .set('Authorization', 'Bearer ' + token);
    return this.http.post(this.baseUrl2 + this.urls.post_complaint_excel,formData, { reportProgress: true, observe: 'events', responseType: 'json' });
  }




    GetComplaintListDate(startDate: any, endDate: any): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    // return this.http.get(this.baseUrl + this.urls.get_complaint_list_for_date+'&startDate='+'01-01-2023'+'&endDate='+'05-01-2023',{ 'headers': headers });
    return this.http.get(this.baseUrl2 + this.urls.get_complaint_list_for_date + '&startDate=' + startDate + '&endDate=' + endDate, { 'headers': headers });
  }
  GetNeedAssistanceList(): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    // return this.http.get(this.baseUrl + this.urls.get_complaint_list_for_date+'&startDate='+'01-01-2023'+'&endDate='+'05-01-2023',{ 'headers': headers });
    return this.http.get(this.baseUrl2 + this.urls.get_need_assistance_list, { 'headers': headers });
  }
  GetPendingList(): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 + this.urls.get_pending_list, { 'headers': headers });
  }
  GetComplaintListById(id: any): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 + this.urls.get_complaint_list_By_Id + id, { 'headers': headers });
  }

  PutComplaintById(id: number): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.put(this.baseUrl2 + this.urls.put_complaint_By_Id + id + '/' + 'CLOSE', {}, { 'headers': headers });
    // return this.http.put(`api/complaints/update/${id}/CLOSE`,{ 'headers': headers });
    // return this.http.put(this.baseUrl + this.urls.put_complaint_By_Id,{ 'headers': headers });
  }
  PutComplaintCommentById(id: number,comment:string): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.put(this.baseUrl2 + this.urls.put_complaint_Comment_By_Id + id + '/' + 'CLOSE', {'comment':comment}, { 'headers': headers });
  }

  // MESSAGE_POST_METHOD
  MessageCreate(data: any): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.post(this.baseUrl2 + this.urls.message_create, data, { 'headers': headers });
  }

  BankCreate(data: any): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.post(this.baseUrl2 + this.urls.Add_bank, data, { 'headers': headers });
  }

  GetSenderList() {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 + this.urls.get_all_sender_data, { 'headers': headers });
  }

  // CHANGE_PASSWORD_PUT_METHOD
  ResetPassword(data: any) {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.post(this.baseUrl2 + this.urls.reset_password_add, data, { 'headers': headers });
  }
  ChangePasswordUpdate(data: any) {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.post(this.baseUrl2 + this.urls.change_password_update, data, { 'headers': headers });
  }

  // SETTING_FORM_IN_ADD_PUT_GET_METHOD
  CoordinatorAdd(data: any) {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.post(this.baseUrl2 + this.urls.coordinator_add, data, { 'headers': headers }).pipe(
tap(() =>{
this._refreshNeeded$
    })
    )
  }
  MemberAdd(data: any) {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.post(this.baseUrl2 + this.urls.member_add, data, { 'headers': headers });
  }


  //Manage_Code_Add_Put_Get
  KoCodeAdd(data: any) {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.post(this.baseUrl2 + this.urls.ko_code_add, data, { 'headers': headers });
  }
  ManageCodeUpdate(data: any) {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.put(this.baseUrl2 + this.urls.manage_ko_code_put, data, { 'headers': headers });
  }
  ManageCodeGetById(id: any) {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 + this.urls.manage_ko_code_get_by_id + id, { 'headers': headers });
  }
  GetAllBankList() {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 + this.urls.get_all_bank_list, { 'headers': headers });
  }


// OnBoarding_Get_Edit
 GetOnBoardingList(){
  var token = localStorage.getItem('token');
  var headers = new HttpHeaders()
    .set('content-type', 'application/json')
    .set('Access-Control-Allow-Origin', '*')
    .set('Authorization', 'Bearer ' + token);
  // return this.http.get(this.baseUrl + this.urls.get_all_on_boarding_list, { 'headers': headers });
  return this.http.get(this.baseUrl2 +'api/onboard/registrations?size=30000&status=PENDING', { 'headers': headers });
}
 DeleteOnBoardingList(id: number){
  var token = localStorage.getItem('token');
  var headers = new HttpHeaders()
    .set('content-type', 'application/json')
    .set('Access-Control-Allow-Origin', '*')
    .set('Authorization', 'Bearer ' + token);
  // return this.http.get(this.baseUrl + this.urls.get_all_on_boarding_list, { 'headers': headers });
  return this.http.delete(this.baseUrl2 +'api/onboard/delete/'+ id, { 'headers': headers });
}


  //BasicInfo_Add_Put_Get
  AddBasicInfo(data: any) {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.post(this.baseUrl2 +'api/onboard/basicInfo', data, { 'headers': headers });
  }

  UploadImgInfo(data: any) {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.post(this.baseUrl2 +'api/documents/upload',data,{ 'headers': headers });
  }

  OnBoardingListGetById(id: number) {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations/'+ id,{ 'headers': headers });
    // return this.http.post('http://techsupport.visel.in:8091/api/onboard/registrations/1',{ 'headers': headers });
  }


// Put_Approved_Reject_list

  PutApprovedById(id: number): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.put(this.baseUrl2 +'api/onboard/registrations/status/'+ id,{"status": "approved"},{ 'headers': headers });
  }

  PutRejectById(id: number): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.put(this.baseUrl2 +'api/onboard/registrations/status/'+ id,{"status": "reject"},{ 'headers': headers });
  }
  getDocById(id: any): Observable<any> {

    // id = localStorage.getItem('userId')
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/documents?koCode=' + id, { 'headers': headers });
  }
  getDocumentById(id: any): Observable<Blob> {

    // id = localStorage.getItem('userId')
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/pdf')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
      // 11271613
    return this.http.get(this.baseUrl2 +'api/documents/download/pdf/' + id, { 'headers': headers,responseType:'blob' });
  }


   getDocumentDownloadById(id: number): Observable<Blob> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('responseType', 'blob')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);

    return this.http.get(this.baseUrl2 +'api/documents/download/' + id,{ responseType: 'blob' ,'headers': headers});
  }

   GetOnBoardingListDate(startDate: any, endDate:any): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'image/jpeg')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?status=PENDING'  + '&startDate=' + startDate + '&endDate=' + endDate, { 'headers': headers });
  }
   GetOnBoardingListKoCode(KoCode: any,): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'image/jpeg')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?status=PENDING'  + '&koCode=' + KoCode, { 'headers': headers });
  }
   GetOnBoardingListBank(Bank: any,): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'image/jpeg')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?status=PENDING'  + '&bankName=' + Bank, { 'headers': headers });
  }


  // get_Approved_And_Filter_list

  // baseUrl2 = environment.baseUrl2;
// baseUrls2
GetOnBoardingApprovedList(){
  var token = localStorage.getItem('token');
  var headers = new HttpHeaders()
    .set('content-type', 'application/json')
    .set('Access-Control-Allow-Origin', '*')
    .set('Authorization', 'Bearer ' + token);
  return this.http.get(this.baseUrl2 +'api/onboard/registrations?size=30000&status=APPROVED', { 'headers': headers });
}

  GetApprovedListDate(startDate: any, endDate:any): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'image/jpeg')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?status=APPROVED'  + '&startDate=' + startDate + '&endDate=' + endDate, { 'headers': headers });
  }
  GetApprovedListKoCode(KoCode: any,): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'image/jpeg')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?status=APPROVED'  + '&koCode=' + KoCode, { 'headers': headers });
  }
  GetApprovedListBank(Bank: any,): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'image/jpeg')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?status=APPROVED'  + '&bankName=' + Bank, { 'headers': headers });

  }



  // get_Rejected_And_Filter_list

  GetOnBoardingRejectList(){
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?size=30000&status=REJECTED', { 'headers': headers });
  }

  GetRejectedListDate(startDate: any, endDate:any): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'image/jpeg')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?status=REJECTED'  + '&startDate=' + startDate + '&endDate=' + endDate, { 'headers': headers });
  }
  GetRejectedListKoCode(KoCode: any,): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'image/jpeg')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?status=REJECTED'  + '&koCode=' + KoCode, { 'headers': headers });
  }

  GetRejectedListBank(Bank: any,): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'image/jpeg')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?status=REJECTED'  + '&bankName=' + Bank, { 'headers': headers });

  }


// get_Non_OnBoarding_And_Filter_list
  GetNonOnBoardingList(){
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    // return this.http.get(this.baseUrl + this.urls.get_all_on_boarding_list, { 'headers': headers });
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?size=30000&status=NOT_INITIATED', { 'headers': headers });
  }

  GetNonOnBoardingListDate(startDate: any, endDate:any): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'image/jpeg')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?status=PENDING'  + '&startDate=' + startDate + '&endDate=' + endDate, { 'headers': headers });
  }
   GetNonOnBoardingListKoCode(KoCode: any,): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'image/jpeg')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?status=PENDING'  + '&koCode=' + KoCode, { 'headers': headers });
  }
   GetNonOnBoardingListBank(Bank: any,): Observable<any> {
    var token = localStorage.getItem('token');
    var headers = new HttpHeaders()
      .set('content-type', 'image/jpeg')
      .set('Access-Control-Allow-Origin', '*')
      .set('Authorization', 'Bearer ' + token);
    return this.http.get(this.baseUrl2 +'api/onboard/registrations?status=PENDING'  + '&bankName=' + Bank, { 'headers': headers });
  }

}
