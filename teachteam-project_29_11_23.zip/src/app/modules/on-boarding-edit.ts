export interface OnBoardingEdit {
  airConditioner: boolean,
  cctv: boolean,
  centreLength : number
  centreType : string
  centreWidth: number
  complaintNo: boolean
  drinkingWater: boolean
  electricity: boolean
  id: number
  instructionBoard: boolean
  powerBackup: boolean
  registers: boolean
  spaceForCentre: boolean
  tablesChairsPresent: boolean


}
