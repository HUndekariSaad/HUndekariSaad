import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Techvant-project';
  // editMode: any;
  data: any;
  editIndex: any;
  form: any;

 public editMode = false;
 src = 'https://vadimdez.github.io/ng2-pdf-viewer/assets/pdf-test.pdf';



  constructor() {
  }

  addData(form:any){
    var val = form.controls;
    const newData ={
      recipient : val.rec.value,
      message : val.msg.value
    }
    if(this.editMode){
      this.data[this.editIndex] = newData;
    }else{
      this.data.push(newData);
    }

  }

  onDel(index:any){
    this.data.splice(index,1);
  }



  // closeModal(id:any){
  //    this.form.reset();
  //   this.editMode=false;
  //   this.ngxSmartModalService.close(id);
  // }

}
