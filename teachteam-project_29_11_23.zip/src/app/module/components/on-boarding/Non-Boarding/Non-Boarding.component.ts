import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ExcelService } from 'src/app/api-service/Excel.service';
import { ApiService } from 'src/app/api-service/api.service';

@Component({
  selector: 'app-Non-Boarding',
  templateUrl: './Non-Boarding.component.html',
  styleUrls: ['./Non-Boarding.component.css']
})
export class NonBoardingComponent implements OnInit {


  public getNonOnBoardingList : any = []
  public onBoardingForm!: FormGroup;
  public submitted:boolean = false;
  public table:any
  myDateValue!: Date;
  public dateValue!: boolean;
  date: any;
  public getKoCode: any = [];
  public getAllBankList:any = []
  public GetDocumentById:any = []
  public collapse:boolean = false;
  public subscription: any;
  public intervalId: any;

  // src = 'https://vadimdez.github.io/ng2-pdf-viewer/assets/pdf-test.pdf';
  src = "";


  constructor(public _ApiService:ApiService,private excel: ExcelService) { }

  ngOnInit() {

    this.GetNonOnBoardingList();
    this.GetUserCoordinatorList()
    this.GetAllBankList()


   // this.GetOnBoardingListKoCode()

    this.onBoardingForm = new FormGroup ({
      // BankName:new FormControl('',[Validators.required]),
      bankName:new FormControl('',[Validators.required]),
      KoCode:new FormControl('',[Validators.required]),
      startDate:new FormControl('',[Validators.required]),
      endDate:new FormControl('',[Validators.required]),
    })

    // this.getRealTimeData()
  }


  getRealTimeData() {
    this.GetNonOnBoardingList()
    clearInterval(this.intervalId);
    this.intervalId = setInterval(() => {
      this.GetNonOnBoardingList();
    }, 10000);
  }


  get f() {
    return this.onBoardingForm.controls;
  }

p:any;
GetNonOnBoardingList(){
    this._ApiService.GetNonOnBoardingList().subscribe((response:any) => {
        this.getNonOnBoardingList = response.registrations;
  })
}

Clear(){
  this.onBoardingForm.reset();
  this.onBoardingForm.controls['startDate'].setErrors(null);
  this.onBoardingForm.controls['endDate'].setErrors(null);
  this.onBoardingForm.controls['KoCode'].setErrors(null);
  this.onBoardingForm.controls['bankName'].setErrors(null);
  this.GetNonOnBoardingList();

}


 // Submit_Excel_Form
 OnSubmit(){
  this.submitted = false;
   if(this.onBoardingForm.value.startDate && this.onBoardingForm.value.endDate){
 if(this.onBoardingForm.value.startDate > this.onBoardingForm.value.endDate ){
alert("Please select End date greater than or equal to Start Date.");
this.dateValue = true;
return
 }
 else
 this.dateValue = false;
 {
  this.submitted = true;
  this.GetOnBoardingListDate()

 }
 }
 if(this.onBoardingForm.value.KoCode){
  this.submitted = true;
  this.GetOnBoardingListKoCode()

 }
 if(this.onBoardingForm.value.bankName){
  this.submitted = true;
  this.GetOnBoardingListBank()

 }
}
GetOnBoardingListDate(){
  var date11 = this.onBoardingForm.controls.startDate.value
var startDate = date11.split("-").reverse().join("-")
var date22 = this.onBoardingForm.controls.endDate.value
var endDate = date22.split("-").reverse().join("-")
    this._ApiService.GetNonOnBoardingListDate(startDate,endDate).subscribe((response:any) => {
      this.getNonOnBoardingList = response.registrations;
  })
}

GetOnBoardingListKoCode(){
  this._ApiService.GetNonOnBoardingListKoCode( this.onBoardingForm.value.KoCode).subscribe((response:any) => {
    this.getNonOnBoardingList = response.registrations;
})
}
GetOnBoardingListBank(){
  this._ApiService.GetNonOnBoardingListBank( this.onBoardingForm.value.bankName).subscribe((response:any) => {
    this.getNonOnBoardingList = response.registrations;
})
}

GetUserCoordinatorList() {
  this._ApiService.GetBankMitraKocodeList().subscribe((response) => {
    this.getKoCode = response;
    // this.selectAllForDropdownItems(response)
  })
}



setCurrentClasses() {
  this.collapse = !this.collapse
  console.log(this.collapse)
    }



    PostComplaintExcel(): void {
      this.excel.exportExcel('ExampleTable');
    }





    GetAllBankList(){
      this._ApiService.GetAllBankList().subscribe((response:any)=>{
        this.getAllBankList =response
      })
    }

    // ngOnDestroy(): void {
    //   this.subscription.forEach((subscription: Subscription) => {
    //     subscription.unsubscribe();
    //   });

    // }
    other:any
    getDocumentDownloadById(id:any){
      this._ApiService.getDocumentDownloadById(id).subscribe((response)=>{
   const url = URL.createObjectURL(response)
        window.open(url);

      })
    }


    getDocumentById(id:any){
      this._ApiService.getDocumentById(id).subscribe((response)=>{
        this.GetDocumentById =response
      })
    }


    pdfSrc: any;
    onFileSelected() {
        let $img: any = document.querySelector('#file');
        if (typeof (FileReader) !== 'undefined') {
            let reader = new FileReader();
            reader.onload = (e: any) => {
                this.pdfSrc = e.target.result;
            };
            reader.readAsArrayBuffer($img.files[0]);
        }
    };

}
