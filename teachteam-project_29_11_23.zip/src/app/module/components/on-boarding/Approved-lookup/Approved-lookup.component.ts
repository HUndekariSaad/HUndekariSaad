import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { interval, Subscription } from 'rxjs';
import { ExcelService } from 'src/app/api-service/Excel.service';
import { ApiService } from 'src/app/api-service/api.service';

@Component({
  selector: 'app-Approved-lookup',
  templateUrl: './Approved-lookup.component.html',
  styleUrls: ['./Approved-lookup.component.css']
})
export class ApprovedLookupComponent implements OnInit {

  public getOnBoardingApprovedList : any = []
  public onBoardingForm!: FormGroup;
  public submitted:boolean = false;
  public table:any
  public intervalId:any
  myDateValue!: Date;
  public dateValue!: boolean;
  date: any;
  public getKoCode: any = [];
  public getAllBankList:any = [];
  public GetDocumentById:any = []
  public collapse:boolean = false;
  public subscription: any;

  constructor(public _ApiService:ApiService,private excel: ExcelService) { }

  ngOnInit() {

    this.GetOnBoardingApprovedList();
    this.GetUserCoordinatorList()
    this.GetAllBankList()

    // this.getRealTimeData()


    this.onBoardingForm = new FormGroup ({
      // BankName:new FormControl('',[Validators.required]),
      bankName:new FormControl('',[Validators.required]),
      KoCode:new FormControl('',[Validators.required]),
      startDate:new FormControl('',[Validators.required]),
      endDate:new FormControl('',[Validators.required]),
    })
  }


  getRealTimeData() {
    this.GetOnBoardingApprovedList()
    clearInterval(this.intervalId);
    this.intervalId = setInterval(() => {
      this.GetOnBoardingApprovedList();
    }, 10000);
  }




  get f() {
    return this.onBoardingForm.controls;
  }

p:any;
GetOnBoardingApprovedList(){
    this._ApiService.GetOnBoardingApprovedList().subscribe((response:any) => {
        this.getOnBoardingApprovedList = response.registrations;
  })
}

Clear(){
  this.onBoardingForm.reset();
  this.onBoardingForm.controls['startDate'].setErrors(null);
  this.onBoardingForm.controls['endDate'].setErrors(null);
  this.onBoardingForm.controls['KoCode'].setErrors(null);
  this.onBoardingForm.controls['bankName'].setErrors(null);
  this.GetOnBoardingApprovedList();

}


 // Submit_Excel_Form
 OnSubmit(){
  this.submitted = false;
   if(this.onBoardingForm.value.startDate && this.onBoardingForm.value.endDate){
 if(this.onBoardingForm.value.startDate > this.onBoardingForm.value.endDate ){
alert("Please select End date greater than or equal to Start Date.");
this.dateValue = true;
return
 }
 else
 this.dateValue = false;
 {
  this.submitted = true;
  this.GetApprovedListDate()

 }
 }
 if(this.onBoardingForm.value.KoCode){
  this.submitted = true;
  this.GetApprovedListKoCode()

 }
 if(this.onBoardingForm.value.bankName){
  this.submitted = true;
  this.GetApprovedListBank()

 }

}
GetApprovedListDate(){
  var date11 = this.onBoardingForm.controls.startDate.value
var startDate = date11.split("-").reverse().join("-")
var date22 = this.onBoardingForm.controls.endDate.value
var endDate = date22.split("-").reverse().join("-")
    this._ApiService.GetApprovedListDate(startDate,endDate).subscribe((response) => {
      this.getOnBoardingApprovedList = response.registrations;
  })
}

GetApprovedListKoCode(){
  this._ApiService.GetApprovedListKoCode( this.onBoardingForm.value.KoCode).subscribe((response) => {
    this.getOnBoardingApprovedList = response.registrations;
})
}


GetApprovedListBank(){
  this._ApiService.GetApprovedListBank( this.onBoardingForm.value.bankName).subscribe((response) => {
    this.getOnBoardingApprovedList = response.registrations;
})
}

GetUserCoordinatorList() {
  this._ApiService.GetBankMitraKocodeList().subscribe((response) => {
    this.getKoCode = response;
    // this.selectAllForDropdownItems(response)
  })
}


public isLoading$:boolean = false;
getDocumentById(id:any){
  this._ApiService.getDocumentById(id).subscribe((response)=>{
    // this.GetDocumentById =response
    const url = URL.createObjectURL(response)
    window.open(url);
    this.isLoading$ = false ;
  })
  this.isLoading$ = true;
}




// getDocumentDownloadById(id:any){
//   this._ApiService.getDocumentDownloadById(id).subscribe((response)=>{
// const url = URL.createObjectURL(response)
//     window.open(url);

//   })
// }


// getDocumentById(id:any){
//   this._ApiService.getDocumentById(id).subscribe((response)=>{
//     this.GetDocumentById =response
//   })
// }





setCurrentClasses() {
  this.collapse = !this.collapse
  console.log(this.collapse)
    }





    PostComplaintExcel(): void {
      this.excel.exportExcel('ExampleTable');
    }





    GetAllBankList(){
      this._ApiService.GetAllBankList().subscribe((response:any)=>{
        this.getAllBankList =response
      })
    }


    // ngOnDestroy(): void {
    //   this.subscription.forEach((subscription: Subscription) => {
    //     subscription.unsubscribe();
    //   });
    //   clearInterval(this.intervalId);
    // }

}
