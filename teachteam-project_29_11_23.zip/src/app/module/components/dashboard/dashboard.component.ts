import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription, combineLatest, interval } from 'rxjs';
import { forkJoin } from 'rxjs/internal/observable/forkJoin';
import { combineLatestWith, map } from 'rxjs/operators';
import { ApiService } from 'src/app/api-service/api.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit,OnDestroy {

  public CommentForm!: FormGroup;
  public submitted: boolean = false;
  public getComplaintPendingList: any = []
  public getPendingList: any = []
  public getComplaintNewList: any = []
  public getComplaintSummary: any = []
  private subscription: Subscription[] = [];
  public getNeedAssistanceList: any = []
  public complaintId: any;
  public ticketData: any = [];
  public  intervalId : any
  public users: any[] = [];
  public sub: any;
  public counters: any;
  public display="none";
  public  display1="none";
  public  editMode = false;

  constructor(public _ApiService: ApiService) {
   }

  ngOnInit() {

    this.CommentForm = new FormGroup ({
      id :new FormControl('',[Validators.required]),
      comment:new FormControl('',[Validators.required]),
    })
    this.GetComplaintNewList();
    this.ComplaintSummary();
    this.GetNeedAssistanceList();
    this.GetComplaintPendingList();


  this.getRealTimeData();


  }

  getRealTimeData() {
    clearInterval(this.intervalId);
    this.intervalId = setInterval(() => {
      this.GetComplaintNewList();
      this.ComplaintSummary();
         this.GetNeedAssistanceList();
         this.GetComplaintPendingList();
    }, 10000);
  }



  OnSubmit(){
    console.log('OnSubmit',this.CommentForm.value.id);
  }

  ngAfterViewInit() {



      // var obs$




    // combineLatest({
    //   users: this._ApiService.GetOpenTicketsNewList(),
    //   contacts: this._ApiService.GetOpenTicketsPendingList(),
    //   addresses: this._ApiService.GetOpenTicketsPendingList()
    // })
    // .pipe(
    //   map(response => {
    //     // if(response!=null){
    //       var users = <Array<any>>response.users.complaints;
    //       var contacts = <Array<any>>response.contacts.complaints;
    //       var addresses = <Array<any>>response.addresses.complaints;
    //       var result: any[] = [];
    //       addresses.filter((user: any) => {
    //         result.push({
    //           ...user,
    //           ...contacts.find((contact: any) => contact.userId === user.userId),
    //           ...addresses.find((address: any) => address.userId === address.userId)})
    //       });
    //       console.log("result ", result)
    //       return result;
    //   })
    // )
    // .subscribe((data) => {
    //   this.users = data;
    // });


  }





  GetComplaintPendingList() {
    this._ApiService.GetOpenTicketsPendingList().subscribe((response) => {
      this.getComplaintPendingList = response.complaints;
    })
  }

  p: any;



  GetComplaintNewList() {
    this._ApiService.GetOpenTicketsNewList().subscribe((response) => {
      this.getComplaintNewList = response.complaints;
    })
  }

  GetNeedAssistanceList() {
    this._ApiService.GetNeedAssistanceList().subscribe((response) => {
      this.getNeedAssistanceList = response;
      // this.GetNeedAssistanceList();
    })
  }


  ComplaintSummary() {
    this._ApiService.ComplaintSummary().subscribe((response) => {
      this.getComplaintSummary = response;
    })
  }


  GetComplaintListById(id: any) {
    // this.display = "block";
    this._ApiService.GetComplaintListById(id).subscribe((Response) => {
      this.getPendingList = Response
      this.CommentForm.get('id')?.patchValue(
        Response.complaintId);
        // this.display = "none";

    })
  }


  // formData: { name: string } = { name: '' };

  // submitForm() {
  //   // Handle form submission logic here
  //   console.log('Form submitted with data:', this.formData);
  //   // Close the modal
  //   document.getElementById('myModal')?.classList.remove('show');
  // }

  closeComplaintList(id: number) {
    this._ApiService.PutComplaintById(id).subscribe((Response) => {
      this.GetNeedAssistanceList();
      this.GetComplaintNewList();
      this.GetComplaintPendingList();
      this.GetComplaintList();
      this.closeComplaintCommentList()
      Swal.fire("Success!", " Close Complaint successfully!", "success");
    })


    // this.display = "none";

  }

  closeComplaintCommentList() {
    //  this.id = this.CommentForm.value.id
    this._ApiService.PutComplaintCommentById(this.CommentForm.value.id,this.CommentForm.value.comment).subscribe((Response) => {
      console.log('Response',Response)
    })
  }

  GetComplaintList(){
    this._ApiService.GetComplaintList().subscribe((response) => {

  })
}

onCloseHandled() {
  this.display = "none";
}


  closeModal(id:any){
    this.editMode=false;
  }


  ngOnDestroy(): void {
    this.subscription.forEach((subscription: Subscription) => {
      subscription.unsubscribe();
    });
    clearInterval(this.intervalId);
  }



}

