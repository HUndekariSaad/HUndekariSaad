import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { combineLatest, map } from 'rxjs';
import { ApiService } from 'src/app/api-service/api.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit {

  public MessageForm!: FormGroup;
  public submitted: boolean = false;
  public isAddMode!: boolean
  public id!: number;
  public requiredField: boolean = false;
  public res: any;
  public selectedItems: any = [];
  public dropdownSettings: any = [];
  public dropdownList: any = [];
  public visible: boolean = true
  public visible2: boolean = false

  public cities: any = [];
  public users: any = [];
  public isValid: boolean = true;


  public getKoCodeList: any = [];
  public CoordinatorList: any = [];
  public selectedCityIds!: string[];
  public City: any = ['admin', 'member'];
  public getSenderData: any = [];
  public Price: any

  public Coordinator: any;
  public recepient: any = [];
  str: string | undefined;
  isAdmin!: boolean;

  constructor(public _ApiService: ApiService, private router: Router,) { }

  ngOnInit() {
    this.GetSenderList()
    this.GetProfile()

    this.GetBankMitraKocodeList()
    this.MessageForm = new FormGroup({
      body: new FormControl('', [Validators.required]),
      recipients: new FormControl('', [Validators.required]),
      sender: new FormControl(localStorage.getItem('roles'), [Validators.required]),
      topic: new FormControl('general'),
      broadcast: new FormControl(false),
      title: new FormControl('New Message'),
    })
    // this.selectAllForDropdownItems(this.getData());

    // combineLatest({
    //   users: this._ApiService.GetBankMitraKocodeList(),
    //   contacts: this._ApiService.GetUserCoordinatorList(),
    //   addresses: this._ApiService.GetUserCoordinatorList(),
    // })
    //   .pipe(
    //     map(response => {
    //       const users = <Array<any>>response.users;
    //       const contacts = <Array<any>>response.contacts;
    //       const addresses = <Array<any>>response.addresses;
    //       const result: any[] = [];
    //       users.map((user: any) => {
    //         result.push({
    //           ...user,
    //           ...contacts.find((contact: any) => contact.userId === user.userId),
    //           ...addresses.find((address: any) => address.userId === address.userId)
    //         })
    //       });
    //       return result;
    //     })
    //   )
    //   .subscribe((data) => {
    //     this.users = data;
    //     this.selectAllForDropdownItems(data)
    //   });

    if(localStorage.getItem('roles') == 'ROLE_ADMIN' ){
      this.isAdmin = true;
      this.GetUserCoordinatorList();
      return
    }
    else
     this.isAdmin = false;
    {
    }

  }


  get f() {
    return this.MessageForm.controls;
  }

  OnSubmit() {
    this.submitted = true;
    if (this.MessageForm.invalid) {
      return
    }
    this.MessageFormCreate()
  }

  MessageFormCreate() {
    this._ApiService.MessageCreate(this.MessageForm.value).subscribe((res) => {
      this.router.navigateByUrl('admin/message');
      Swal.fire("Success!", "Messege Send  successfully!", "success");
      this.MessageForm.controls.body.reset();
      // this.MessageForm.controls.sender.reset();
      this.MessageForm.controls.recipients.reset();
      this.MessageForm.controls['body'].setErrors(null);
      // this.MessageForm.controls['sender'].setErrors(null);
      this.MessageForm.controls['recipients'].setErrors(null);
      this.submitted = false;
    })
  }

  Delete() {
    // this.MessageForm.reset();
    this.MessageForm.controls.body.reset();
    // this.MessageForm.controls.sender.reset();
    this.MessageForm.controls.recipients.reset();
    this.MessageForm.controls['body'].setErrors(null);
    this.MessageForm.controls['recipients'].setErrors(null);
    // this.MessageForm.controls['sender'].setErrors(null);
    this.submitted = false;
  }

  GetSenderList() {
    this._ApiService.GetSenderList().subscribe((res) => {
      this.dropdownSettings = res
    })

  }

  GetBankMitraKocodeList() {
    this._ApiService.GetBankMitraKocodeList().subscribe((response) => {
      this.getKoCodeList = response;
      this.cities = response;
       this.selectAllForDropdownItems(response)
    })
  }
  GetUserCoordinatorList() {
    this._ApiService.GetUserCoordinatorList().subscribe((response) => {
      this.CoordinatorList = response;
      this.selectAllForDropdownItems(response)
    })
  }

  GetProfile() {
    this._ApiService.GetProfile().subscribe((response) => {
      this.getSenderData = response;
    })
  }



  setStatus() {
    this.selectedItems.length > 0
      ? (this.requiredField = true)
      : (this.requiredField = false);
  }

  setClass() {
    this.setStatus();
    if (this.selectedItems.length > 0) {
      return 'validField';
    } else {
      return 'invalidField';
    }
  }

  submission() {
    if (this.requiredField == false) {
    }
  }


  onItemSelect(item: any) {
    console.log(item);
  }
  onSelectAll(item: any) {
    console.log(item);
  }

  all: any
  onMaterialGroupChange(event: any) {
    console.log(event);
    let str
    if (event.length > 0 && event[0]?.all && !event[0]?.id) {
      str = event[0]?.all;
    } else {
      str = event
    }

    if (str == "all") {
      this.MessageForm.get('broadcast')?.patchValue(true);
    } else {
      this.MessageForm.get('broadcast')?.patchValue(false);
    }
  }

  changeValue() {
  }

  selectAllForDropdownItems(items: any[]) {
    let allSelect = (items: any) => {
      items.forEach((element: any) => {
        element['all'] = 'all';
      });
    };

    allSelect(items);

  }


  onclick() {

    this.visible = !this.visible; //not equal to condition
    this.visible2 = !this.visible2
  }


}


