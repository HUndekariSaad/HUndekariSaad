/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { MyPipePipe } from './my-pipe.pipe';

describe('Pipe: MyPipee', () => {
  it('create an instance', () => {
    let pipe = new MyPipePipe();
    expect(pipe).toBeTruthy();
  });
});
