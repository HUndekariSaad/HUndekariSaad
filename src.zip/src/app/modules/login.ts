export interface Login {
    koCode: string,
    userPassword: string,
    token?: string;
    user_role:string;
}
