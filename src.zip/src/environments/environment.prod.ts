export const environment = {
  production: true,
  baseUrl: 'http://172.16.16.12:8090/',
  baseUrls: 'http://172.16.16.12:8090/'
  // baseUrl: 'http://techsupport.visel.in:8090/',
  // baseUrls: 'http://techsupport.visel.in:8090/',
};
