export class ReportParams{
  startDate='';
  endDate='';
}
export class ReportParamsIdParams{

  quotationID= 0;
  pageNumber=1;
  pageSize=5;
}
