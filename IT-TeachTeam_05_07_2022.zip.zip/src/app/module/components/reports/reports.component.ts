
import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { interval, Subscription } from 'rxjs';
import { ApiService } from 'src/app/api-service/api.service';
import { ExcelService } from 'src/app/api-service/Excel.service';
import { ReportParams } from 'src/app/modules/_modules/reportParams';
import Swal from 'sweetalert2';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css'],
})
export class ReportsComponent implements OnInit,OnDestroy {

  public getcomplaintlist : any = []
  private subscription: Subscription[] = [];
  public ReportForm!: FormGroup;
  public submitted:boolean = false;
  public table:any
  public counters:any
  public intervalId:any
  myDateValue!: Date;
  public dateValue!: boolean;
  date: any;
  // date.split("/").reverse().join("-")


  constructor(public _ApiService:ApiService,private excel: ExcelService) {}

  ngOnInit() {
    // this.GetComplaintList();
    // this.counters = interval(50000);
    // this.counters.subscribe((d:any)=>{
    //   console.log(d);
    //   this.GetComplaintList();
    // })

    this.ReportForm = new FormGroup ({
      startDate:new FormControl('',[Validators.required]),
      endDate:new FormControl('',[Validators.required]),
    });
    this.getRealTimeData()
  }

  getRealTimeData() {
    this.GetComplaintList()
    clearInterval(this.intervalId);
    this.intervalId = setInterval(() => {
      this.GetComplaintList();
    }, 40000);
  }




  get f() {
    return this.ReportForm.controls;
  }

p:any;
  GetComplaintList(){
    this._ApiService.GetComplaintList().subscribe((response) => {
        this.getcomplaintlist = response.complaints;
  })
}

Clear(){
  this.ReportForm.reset();
  this.ReportForm.controls['startDate'].setErrors(null);
  this.ReportForm.controls['endDate'].setErrors(null);
  this.GetComplaintList();

}


 // Submit_Excel_Form
 OnSubmit(){
  this.submitted = false;
 if(this.ReportForm.value.startDate > this.ReportForm.value.endDate ){
alert("Please select End date greater than or equal to Start Date.");
this.dateValue = true;
return
 }
 else
 this.dateValue = false;
 {
  this.submitted = true;
  this.GetComplaintListDate()
 }
}
GetComplaintListDate(){
  var date11 = this.ReportForm.controls.startDate.value
var startDate = date11.split("-").reverse().join("-")
var date22 = this.ReportForm.controls.endDate.value
var endDate = date22.split("-").reverse().join("-")
    this._ApiService.GetComplaintListDate(startDate,endDate).subscribe((response) => {
      this.getcomplaintlist = response.complaints;
  })
}

PostComplaintExcel(): void {
  this.excel.exportExcel('ExampleTable');
}



ngOnDestroy(): void {
  this.subscription.forEach((subscription: Subscription) => {
    subscription.unsubscribe();
  });
  clearInterval(this.intervalId);
}
}


