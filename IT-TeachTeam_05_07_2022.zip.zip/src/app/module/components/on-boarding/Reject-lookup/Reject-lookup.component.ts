import { Component, OnInit } from '@angular/core';
import { interval, Subscription } from 'rxjs';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ExcelService } from 'src/app/api-service/Excel.service';
import { ApiService } from 'src/app/api-service/api.service';

@Component({
  selector: 'app-Reject-lookup',
  templateUrl: './Reject-lookup.component.html',
  styleUrls: ['./Reject-lookup.component.css']
})
export class RejectLookupComponent implements OnInit {

  public getOnBoardingRejectList : any = []
  public onBoardingForm!: FormGroup;
  public submitted:boolean = false;
  public table:any
  myDateValue!: Date;
  public dateValue!: boolean;
  date: any;
  public getKoCode: any = [];
  public getAllBankList:any = []
  public GetDocumentById:any = []
  public collapse:boolean = false;
  public subscription: any;
   public intervalId:any

  constructor(public _ApiService:ApiService,private excel: ExcelService) { }

  ngOnInit() {

    this.GetOnBoardingRejectList();
    this.GetUserCoordinatorList()
    this.GetAllBankList()

    // this.getRealTimeData()

    this.onBoardingForm = new FormGroup ({
      bankName:new FormControl('',[Validators.required]),
      KoCode:new FormControl('',[Validators.required]),
      startDate:new FormControl('',[Validators.required]),
      endDate:new FormControl('',[Validators.required]),
    });

  }


  getRealTimeData() {
    this.GetOnBoardingRejectList()
    clearInterval(this.intervalId);
    this.intervalId = setInterval(() => {
      this.GetOnBoardingRejectList();
    }, 10000);
  }

  get f() {
    return this.onBoardingForm.controls;
  }

p:any;
GetOnBoardingRejectList(){
    this._ApiService.GetOnBoardingRejectList().subscribe((response:any) => {
        this.getOnBoardingRejectList = response.registrations;
  })
}

Clear(){
  this.onBoardingForm.reset();
  this.onBoardingForm.controls['startDate'].setErrors(null);
  this.onBoardingForm.controls['endDate'].setErrors(null);
  this.onBoardingForm.controls['KoCode'].setErrors(null);
  this.onBoardingForm.controls['bankName'].setErrors(null);
  this.GetOnBoardingRejectList();

}


  // Submit_Excel_Form
  OnSubmit(){
    this.submitted = false;
     if(this.onBoardingForm.value.startDate && this.onBoardingForm.value.endDate){
   if(this.onBoardingForm.value.startDate > this.onBoardingForm.value.endDate ){
  alert("Please select End date greater than or equal to Start Date.");
  this.dateValue = true;
  return
   }
   else
   this.dateValue = false;
   {
    this.submitted = true;
    this.GetRejectedListDate()

   }
   }
   if(this.onBoardingForm.value.KoCode){
    this.submitted = true;
    this.GetRejectedListKoCode()

   }
   if(this.onBoardingForm.value.bankName){
    this.submitted = true;
    this.GetRejectedListBank()

   }
  }
  GetRejectedListDate(){
    var date11 = this.onBoardingForm.controls.startDate.value
  var startDate = date11.split("-").reverse().join("-")
  var date22 = this.onBoardingForm.controls.endDate.value
  var endDate = date22.split("-").reverse().join("-")
      this._ApiService.GetRejectedListDate(startDate,endDate).subscribe((response) => {
        this.getOnBoardingRejectList = response.registrations;
    })
  }

  GetRejectedListKoCode(){
    this._ApiService.GetRejectedListKoCode( this.onBoardingForm.value.KoCode).subscribe((response) => {
      this.getOnBoardingRejectList = response.registrations;
  })
  }
  GetRejectedListBank(){
    this._ApiService.GetRejectedListBank( this.onBoardingForm.value.bankName).subscribe((response) => {
      this.getOnBoardingRejectList = response.registrations;
  })
  }

  GetUserCoordinatorList() {
    this._ApiService.GetBankMitraKocodeList().subscribe((response) => {
      this.getKoCode = response;
      // this.selectAllForDropdownItems(response)
    })
  }

setCurrentClasses() {
  this.collapse = !this.collapse
  console.log(this.collapse)
    }




    PostComplaintExcel(): void {
      this.excel.exportExcel('ExampleTable');
    }





    GetAllBankList(){
      this._ApiService.GetAllBankList().subscribe((response:any)=>{
        this.getAllBankList =response
      })
    }


    getDocumentDownloadById(id:any){
      this._ApiService.getDocumentDownloadById(id).subscribe((response)=>{
    const url = URL.createObjectURL(response)
        window.open(url);

      })

    }



    public isLoading$:boolean = false;
getDocumentById(id:any){
  this._ApiService.getDocumentById(id).subscribe((response)=>{
    // this.GetDocumentById =response
    const url = URL.createObjectURL(response)
    window.open(url);
    this.isLoading$ = false ;
  })
  this.isLoading$ = true;
}


    // getDocumentById(id:any){
    //   this._ApiService.getDocumentById(id).subscribe((response)=>{
    //     this.GetDocumentById =response
    //   })
    // }


    // ngOnDestroy(): void {
    //   this.subscription.forEach((subscription: Subscription) => {
    //     subscription.unsubscribe();
    //   });
    //   clearInterval(this.intervalId);
    // }

}
