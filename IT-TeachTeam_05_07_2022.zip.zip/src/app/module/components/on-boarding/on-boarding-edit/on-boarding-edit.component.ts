import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs';
import { ApiService } from 'src/app/api-service/api.service';
import { OnBoardingEdit } from 'src/app/modules/on-boarding-edit';

@Component({
  selector: 'app-on-boarding-edit',
  templateUrl: './on-boarding-edit.component.html',
  styleUrls: ['./on-boarding-edit.component.css']
})
export class OnBoardingEditComponent implements OnInit {

  public ItInfrastructureForm!: FormGroup;
  public BasicInfoForm!: FormGroup;
  public BankDetailsForm!: FormGroup;
  public ImgUploadForm!: FormGroup;
  public OtherInfrastructureForm!: FormGroup;
  public submitted:boolean = false;
  public Submitted:boolean = false;
  public Submit:boolean = false;
  public submit:boolean = false;
  // activeTabone:boolean;
  activeTabTwo:boolean=false;
  activeOne:boolean=false;
  activeTwo:boolean=false;
  activeThere:boolean=false;
  activeZero:boolean=true;
  public id :any;
  public userid :any;
  public imageSrc: any ;
  public imageSrc2: any ;
  public imageSrc3: any ;

  public onboardingEdit!: OnBoardingEdit;


  public isImageFail1: boolean= false;
  public isImageSuccess1: boolean = false;
  public images: any;

  isImageSaved: boolean = false;
  base64Images: any;


  public  isAddMode: boolean = false;
  public step:any
public active: boolean = false;
  routeSub: any;
  domSanitizer: any;
  Files: any;
  // viewImage: string;

  formBuilder: any;
  myFiles:string [] = [];
  public documents: any = [];
  urls = []
  // public yes:any
  constructor(private router: Router, private route: ActivatedRoute,public _ApiService: ApiService,private fb: FormBuilder) { }

  ngOnInit() {
    // this.getDocById();
    this.id = this.route.snapshot.params['id'];
    this.isAddMode = !this.id;
    if (!this.isAddMode) {
      this.routeSub = this.route.params.subscribe(params => {
      console.log(params)
      console.log('get id',params['id'])
      this._ApiService.OnBoardingListGetById(this.id)
     .subscribe(x =>{
      var temp: any = x
        this.BasicInfoForm.patchValue(temp.onboardBasicInfo);
        this._ApiService.getDocById(temp.fbcKoCode).subscribe( x=>{

  this.documents  =  x
        })

        this.OtherInfrastructureForm.get('birthDate')?.patchValue(other.onboardBasicInfo.birthDate)
        // this.OtherInfrastructureForm.get('userId')?.patchValue(other.onboardBasicInfo.id)

        let bdetail: any = x
        this.BankDetailsForm.patchValue(bdetail.onboardBankAccountDetails);
        var Itinfo: any = x
        this.ItInfrastructureForm.patchValue(Itinfo.onboardItInfra);
       var other:any = x
        this.OtherInfrastructureForm.patchValue(other.onboardOtherInfra);

        // this.OtherInfrastructureForm.get('centreType')?.patchValue(other.onboardOtherInfra.spaceForCentre);

     });
    });
    }else {
      console.log('id is not available')
    }


    this.BasicInfoForm = new FormGroup ({
      fbcTitle:new FormControl('',[Validators.required]),
      firstName:new FormControl('',[Validators.required]),
      middleName:new FormControl('',[Validators.required]),
      lastName:new FormControl('',[Validators.required]),
      oname:new FormControl('',[Validators.required]),
      motherName:new FormControl(''),
      gender:new FormControl('',[Validators.required]),
      birthDate:new FormControl(this.formatDate(new Date()),[Validators.required]),
      maritalStatus:new FormControl('',[Validators.required]),
      education:new FormControl('',[Validators.required]),
      religion:new FormControl('',[Validators.required]),
      resAddress:new FormControl('',[Validators.required]),
      locAddress:new FormControl('',[Validators.required]),
      mobileNo:new FormControl('',[Validators.required]),
      altMobileNo:new FormControl('',[Validators.required]),
      aaddharNo:new FormControl('',[Validators.required]),
      panNo:new FormControl('',[Validators.required]),
      iibfDetail:new FormControl('',[Validators.required]),
      pvc:new FormControl('',[Validators.required]),
      knownLanguages:new FormControl('',[Validators.required]),
      currentOccupation:new FormControl('',[Validators.required]),
      annualIncome:new FormControl('',[Validators.required]),
      latitude:new FormControl('',[Validators.required]),
      longitude:new FormControl('',[Validators.required]),

      // panNoupload:new FormControl(''),
      // addhaarnoupload:new FormControl(''),
      // PoliceVerificationDetails:new FormControl(''),

    })

    this.BankDetailsForm = new FormGroup ({
      bankName:new FormControl('',[Validators.required]),
      customerId:new FormControl('',[Validators.required]),
      savingAcNo:new FormControl('',[Validators.required]),
      ifscCode:new FormControl('',[Validators.required]),
      settlementAcNo:new FormControl('',[Validators.required]),
      payments:new FormControl('',[Validators.required]),
      securityDeposit:new FormControl(''),
      secDepRecDate:new FormControl(''),
      regCharge:new FormControl('',[Validators.required]),
      regId:new FormControl(0),
    })

    this.ItInfrastructureForm = new FormGroup ({
      fpd:new FormControl('',[Validators.required]),
      fpdSrNo:new FormControl('',[Validators.required]),
      internetConnectivity1:new FormControl('',[Validators.required]),
      internetConnectivity2:new FormControl('',[Validators.required]),
      irisDevice:new FormControl('',[Validators.required]),
      irisDeviceMake:new FormControl(''),
      irisDeviceSrNo:new FormControl(''),
      asset:new FormControl('',[Validators.required]),
      assetMacId:new FormControl('',[Validators.required]),
      assetOsVersion:new FormControl('',[Validators.required]),
      mobileNo1:new FormControl(''),
      mobileNo2:new FormControl(''),
      passbookPrinter:new FormControl('',[Validators.required]),
      passbookPrinterMake:new FormControl(''),
      passbookPrinterSrNo:new FormControl(''),
      pinpadDevice:new FormControl('',[Validators.required]),
      pinpadDeviceMake:new FormControl('',[Validators.required]),
      pinpadDeviceSrNo:new FormControl('',[Validators.required]),
      pos:new FormControl('',[Validators.required]),
      posSrNo:new FormControl(''),
      receiptPrinter:new FormControl('',[Validators.required]),
      receiptPrinterSrNo:new FormControl('',[Validators.required]),
      regId:new FormControl(),
      smartphone:new FormControl('',[Validators.required]),
      smartphoneOsVersion:new FormControl(''),
      smartphoneImeiNo:new FormControl(''),
      tablet:new FormControl('',[Validators.required]),
      tabletOsVersion :new FormControl(''),
      tabletImeiNo:new FormControl(''),

      // PrintDeviceSrNo:new FormControl('',[Validators.required]),
      // desktop:new FormControl('',[Validators.required]),
      // desktopMacId:new FormControl('',[Validators.required]),
      // desktopOsVersion:new FormControl('',[Validators.required]),

    })

    this.OtherInfrastructureForm = new FormGroup ({
      airConditioner:new FormControl('',[Validators.required]),
      cctv:new FormControl('',[Validators.required]),
      centreLength:new FormControl('',[Validators.required]),
      centreType:new FormControl(''),
      centreWidth:new FormControl('',[Validators.required]),
      complaintNo:new FormControl('',[Validators.required]),
      drinkingWater:new FormControl('',[Validators.required]),
      electricity:new FormControl('',[Validators.required]),
      instructionBoard:new FormControl('',[Validators.required]),
      powerBackup:new FormControl("",[Validators.required]),
      regId:new FormControl(this.id),
      registers:new FormControl('',[Validators.required]),
      spaceForCentre:new FormControl('',[Validators.required]),
      tablesChairsPresent:new FormControl('',[Validators.required]),
      vehicleAvailability:new FormControl('',[Validators.required]),

      // SizeofCentre:new FormControl('yes'),
      // tickas:new FormControl('yes'),

    })


    this.ImgUploadForm= new FormGroup ({
      docType:new FormControl('',[Validators.required]),
      documents:new FormControl('',[Validators.required]),
      userId:new FormControl(this.id),
      // items: new FormArray([
      //   this.formBuilder.group({
      //   item:['']
      //   // documents:new FormControl('',[Validators.required]),
      //   // userId:new FormControl(this.id),
      //   })
      // ]),

    //   documents: this.formBuilder.array([
    //     this.formBuilder.group({
    //       documents: [],
    // })
    // ])
    // documents: this.fb.array([this.fb.control('')])
  })
  }

  private formatDate(date:any) {
    let newDate = new Date(date);
    return newDate.toJSON().split('T')[0];
  }





  oOnSelectFile(event:any) {
    if (event.target.files && event.target.files[0]) {
      var filesAmount = event.target.files.length;
      (this.ImgUploadForm.get('file') as FormArray).push(
      this.fb.control(<File>event.target.files[0])
    );
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();

        reader.onload = (event: any) => {
          // this.urls.push(event.target.result);
        };

        reader.readAsDataURL(event.target.files[i]);
      }
    }
  }



  onFileChange(event:any) {
    for (var i = 0; i < event.target.files.length; i++) {

        this.myFiles.push( event.target.files[0]);
        // var myFiles = event.target.files[0];
        console.log('===============',this.myFiles)
        // this.ImgUploadForm.value.documents.get('documents').patchValue(this.myFiles)
        // this.BankDetailsForm.get('ifscCode').patchValue(x.fbcKoCode);
    }
}



 // Submit_Basic_Info_Form
  get f() {
    return this.BasicInfoForm.controls;
  }
  OnSubmitBasicInfo(){
    // debugger
    this.submitted = true;
    if(this.BasicInfoForm.invalid){
      return
    }
    this.submitted = false;
    this.activeThere = false;
    this.activeTwo = false;
    this.activeZero = false;
    this.activeOne = true;

    // this. AddBasicInfo();
  }
  AddBasicInfo(){
    this._ApiService.AddBasicInfo(this.BasicInfoForm.value).subscribe((Response)=>{
      console.log('AddBasicInfo',this.BasicInfoForm.value)
    })
  }

  DeleteBasicInfo(){
    this.ItInfrastructureForm.value.reset();
  }

  OnSubmitUploadImgInfo(){
//     this.Submitted = true;
// if(this.BankDetailsForm.invalid){
//   return
// }
console.log('ImgUploadForm',this.ImgUploadForm.value)
// this.UploadImgInfo()
}




  // UploadImgInfo(){

  //   this._ApiService.UploadImgInfo(this.ImgUploadForm.value).subscribe((res)=>{
  //     console.log(res);
  //   })
  // }




 // Submit_Bank_Details_Form
  get F() {
    return this.BankDetailsForm.controls;
  }
  OnSubmitBankDetails(){
        this.Submitted = true;
    if(this.BankDetailsForm.invalid){
      return
    }
    this.Submitted = false;
    console.log('OnSubmit',this.BankDetailsForm.value);
    this.activeThere = false;
    this.activeTwo = true;
    this.activeZero = false;
    this.activeOne = false;

  }

  deleteBankDetails(){
    this.BankDetailsForm.value.reset();
  }
  ButtonPervious1(){
    this.activeThere = false;
    this.activeTwo = false;
    this.activeZero = true;
    this.activeOne = false;
  }




 // Submit_It_Infrastructure_Form
  get v() {
    return this.ItInfrastructureForm.controls;
  }
  OnSubmitItInfra(){
    this.Submit = true;
    if(this.ItInfrastructureForm.invalid){
      return
    }
    this.Submit = false;
    console.log('OnSubmit',this.ItInfrastructureForm.value)
    // this.ManageCodeUpdate();
    this.activeThere = true;
    this.activeTwo = false;
    this.activeZero = false;
    this.activeOne = false;
  }

  Delete(){
    this.ItInfrastructureForm.value.reset();
  }
  ButtonPervious2(){
    this.activeThere = false;
    this.activeTwo = false;
    this.activeZero = false;
    this.activeOne = true;
  }








 // Submit_Basic_Info_Form
  get V() {
    return this.OtherInfrastructureForm.controls;
  }
  OnSubmitOtherInfra(){
    this.submit = true;
    if(this.OtherInfrastructureForm.invalid){
      return
    }
    this.submit = false;
    console.log('OnSubmit',this.OtherInfrastructureForm.value)
  }

  deleteOtherInfra(){
    this.OtherInfrastructureForm.value.reset();
  }
  ButtonPervious3(){
    this.activeThere = false;
    this.activeTwo = true;
    this.activeZero = false;
    this.activeOne = false;
  }




  PutApprovedById(){
    this.submit = true;
      if(this.OtherInfrastructureForm.invalid){
        return
      }
      this.submit = false;
    this._ApiService.PutApprovedById(this.id).subscribe((res)=>{
    })

    this.router.navigateByUrl('/admin/approved-list');
    this.GetOnBoardingApprovedList()

  };

  GetOnBoardingApprovedList(){
    this._ApiService.GetOnBoardingApprovedList().subscribe((response) => {
  })
}



  PutRejectById(){
    this.submit = true;
    if(this.OtherInfrastructureForm.invalid){
      return
    }
    this.submit = false;
    this._ApiService.PutRejectById(this.id).subscribe((res)=>{
    })
    this.router.navigateByUrl('admin/reject-list');
    this.GetOnBoardingRejectList()
  };

GetOnBoardingRejectList(){
    this._ApiService.GetOnBoardingRejectList().subscribe((response) => {
  })
}

  readURL(event: any): void {
    if (event.target.files && event.target.files[0]) {
        var file = event.target.files[0];
        const reader = new FileReader();
        reader.onload = e => this.imageSrc = reader.result;

        reader.readAsDataURL(file);
        file.push(this.myFiles);
        // this.ImgUploadForm.get("documents").setValue(image);
        this.ImgUploadForm.get('document')?.patchValue(file)
        // file = this.ImgUploadForm.value.documents;
        // console.log('file',file);
    }
}
  readURL2(event: any): void {
    if (event.target.files && event.target.files[0]) {
        var file = event.target.files[0];

        const reader = new FileReader();
        reader.onload = e => this.imageSrc2 = reader.result;

        reader.readAsDataURL(file);
    }
}
  readURL3(event: any): void {
    if (event.target.files && event.target.files[0]) {
        var file = event.target.files[0];

        const reader = new FileReader();
        reader.onload = e => this.imageSrc3 = reader.result;

        reader.readAsDataURL(file);
    }
}



// changeListener($event:any) : void {
//   this.readThis($event.target);
//   this.ImgUploadForm.value.documents = this.readThis($event.target);
// }

// readThis(inputValue: any): void {
//   var file:File = inputValue.files[0];
//   var myReader:FileReader = new FileReader();

//   myReader.onloadend = (e) => {
//     this.image = myReader.result;
//     this.ImgUploadForm.value.documentData = this.image
//     console.log(myReader.result);
//   }
//   myReader.readAsDataURL(file);
// }


getFileDetails (e:any) {
  //console.log (e.target.files);
  for (var i = 0; i < e.target.files.length; i++) {
    this.myFiles.push(e.target.files[i]);


  }
  this.myFiles = this.ImgUploadForm.value.documents
  console.log('img',this.myFiles);

  // const reader = new FileReader();
  // reader.onload = e => this.imageSrc = reader.result;

  // reader.readAsDataURL(this.myFiles);
}


onFileSelected(event: any) {
  for (let i = 0; i < event.target.files.length; i++) {
    const file = event.target.files[i];
    if (file.size > 500000) {
      console.error(`File ${file.name} is too large`);
      alert("File size is too large..")
    } else {
      // Check if the image is already in the array
      const duplicateImage = this.images.find((img: any) => img.name === file.name);
      if (!duplicateImage) {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
          const image = {
            name: file.name,
            base64Image: reader.result,
          };
          this.images.push(image);


          // Convert the image to a base64 string and add it to the array
          reader.onload = () => {
            this.base64Images.push(reader.result as string);
          };
          reader.readAsDataURL(file);
        };
      }
    }
  }
}


// urls = [];
// file = [];
result : any[] = [];
//  result : any[] = [];
onSelectFile(event:any) {
  // if (event.target.files && event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
              var reader = new FileReader();

              reader.onload = (event:any) => {
                console.log(event.target.result);
                 this.result.push(event.target.result);
              }

              reader.readAsDataURL(event.target.files[i]);
      }
  // }
}




fileList: File[] = [];
listOfFiles: any[] = [];
isLoading = false;

onFileChanged(event: any) {
  this.isLoading = true;
  for (var i = 0; i <= event.target.files.length - 1; i++) {
    var selectedFile = event.target.files[i];
    if (this.listOfFiles.indexOf(selectedFile.name) === -1) {
      this.fileList.push(selectedFile);
      this.listOfFiles.push(selectedFile.name);
      console.log('selectedFile',selectedFile.name)
    }
  }

  this.isLoading = false;

  //this.attachment.nativeElement.value = '';
}

removeSelectedFile(index:any) {
  // Delete the item from fileNames list
  this.listOfFiles.splice(index, 1);
  // delete file from FileList
  this.fileList.splice(index, 1);
}


}




  // ManageCodeUpdate(){
  //   this._ApiService.ManageCodeUpdate(this.UpdateKoCodeForm.value).subscribe((response)=>{
  //     this.router.navigateByUrl('admin/managecode');
  //     Swal.fire("Success!", " Update ManageCode successfully!","success");
  //     this.UpdateKoCodeForm.reset();
  //     this.UpdateKoCodeForm.controls['bankName'].setErrors(null);
  //     this.UpdateKoCodeForm.controls['koCode'].setErrors(null);
  //     this.UpdateKoCodeForm.controls['mobileNumber'].setErrors(null);
  //     this.UpdateKoCodeForm.controls['name'].setErrors(null);
  //     this.UpdateKoCodeForm.controls['coOrdinatorId'].setErrors(null);
  //   })
  // }
