import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { AuthGuard } from './auth/auth.guard';


const routes: Routes = [
   { path: '', redirectTo: '/login', pathMatch:'full'},
  { path: 'login',component:LoginComponent},
  // { path: 'dash',component:DashboardComponent},

  // data: { returnUrl: window.location.pathname }

  // { path: 'admin', loadChildren: () => import('./module/adimn/adimn.module').then(m => m.AdimnModule) },
  { path: 'admin',canActivate:[AuthGuard], loadChildren: () => import('./module/adimn/adimn.module').then(m => m.AdimnModule) },
  { path:'**',component:LoginComponent},
];

// canActivate: [LoginGuard]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
